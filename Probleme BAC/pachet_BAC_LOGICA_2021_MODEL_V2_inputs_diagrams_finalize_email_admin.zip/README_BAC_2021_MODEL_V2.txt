Pachet BAC Logică 2021 - Model

Conține examen elev, rezolvare profesor teacher-only, contract diagrame, flow finalizare/preview/email/admin, prompt implementare, contract UI, PDF preview profesor și PDF-urile originale.

Verificare efectuată pe subiectul și baremul încărcate pentru 2021 Model.
