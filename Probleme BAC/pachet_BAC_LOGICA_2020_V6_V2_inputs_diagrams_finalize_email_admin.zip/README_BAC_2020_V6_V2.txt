Pachet BAC Logica 2020 - Varianta 6.

Contine examenul elevului fara solutii, rezolvarea profesorului teacher-only, contractele de diagrame, fluxul de finalizare/preview/email/raport admin, promptul de implementare si documentele originale.
