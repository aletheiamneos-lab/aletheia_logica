Pachet BAC Logica 2018 Varianta 9 - examen elev + rezolvare profesor JSON backend + diagrame + finalizare/email/admin report.
