Pachet BAC Logică 2020 - Model. Conține examen elev, rezolvare profesor teacher-only, contract diagrame, flux finalizare/PDF/email/admin și preview PDF.
