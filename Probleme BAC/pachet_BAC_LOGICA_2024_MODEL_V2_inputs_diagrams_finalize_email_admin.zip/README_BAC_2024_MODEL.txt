Pachet BAC Logică 2024 - Model V2

Acest pachet conține examenul elevului, rezolvarea profesorului în JSON backend, contractul pentru diagrame, fluxul de finalizare/preview/email/raport admin, promptul de implementare și preview PDF generat automat.

Respectă regula: elevul vede doar examenul; profesorul/adminul vede rezolvarea.
