Pachet BAC Logica 2019 Varianta 1. Contine examen elev, rezolvare profesor teacher-only, contract diagrame, finalizare test, preview, email si raport administrator.
