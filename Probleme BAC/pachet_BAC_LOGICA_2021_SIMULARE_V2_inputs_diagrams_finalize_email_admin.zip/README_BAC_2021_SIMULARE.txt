Pachet BAC Logică 2021 - Simulare

Conține examen elev, rezolvare profesor teacher-only, contract diagrame, flux finalizare/preview/email/raport admin și PDF preview.
Sursa unică pentru soluții este teacher_solution_bac_logica_2021_simulare_BACKEND.json.
